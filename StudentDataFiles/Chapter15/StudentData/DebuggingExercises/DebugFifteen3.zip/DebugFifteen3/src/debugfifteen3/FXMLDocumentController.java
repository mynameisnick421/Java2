/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package debugfifteen3;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import static javafx.scene.paint.Color.YELLOW;
import static javafx.scene.paint.Color.BLUE;
import static javafx.scene.paint.Color.GREEN;
import static javafx.scene.paint.Color.PURPLE;

/**
 *
 * @author profs
 */
public class FXMLDocumentController implements Initializable 
  {
    
 ObservableList<String> ColorsList = FXCollections.observableArrayList("Blue","Red", "Green", "Yellow", "Purple");  
  
 
    @FXML
    private Label lblColor;
    @FXML
    private ListView lstColors;
    @FXML
    private Button button;
    
   @FXML
    private void chooseColors() 
    {
  
        if (lstColors.getSelectionModel().getSelectedItem().equals("Blue"))
            {
            lblColor.setText("Blue");
            lblColor.setTextFill(BLUE);
            }    
        else  if (lstColors.getSelectionModel().getSelectedItem().equals("Red"))
           {
            lblColor.setText("Red");
             lblColor.setTextFill(RED);
            
          }
        else  if(lstColors.getSelectionModel().getSelectedItem().equals("Green"))
          {
           lblColor.setText("Green");
            lblColor.setTextFill(GREEN);
           
          }    
        else  if (lstColors.getSelectionModel().getSelectedItem().equals("Yellow"))
           {
           lblColor.setText("Yellow");
            lblColor.setTextFill(YELLOW);
            
          }
        else if(lstColors.getSelectionModel().getSelectedItem().equals("Purple"))
           {
           lblColor.setText("Purple");
            lblColor.setTextFill(PURPLE);
            
          }
      
            
    }
    
   @Override
    public void initialize(URL url, ResourceBundle rb) 
    
    {
         lstColors.setId("Blue");
      
         lstColors.setItems(ColorList);
         
         lstColors.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
         
       
    }    
    
     
    
}
